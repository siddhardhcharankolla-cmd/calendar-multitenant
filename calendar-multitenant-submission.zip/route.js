﻿import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

/**
 * Dev helper route: GET /api/events
 * - supports query params used by UI: select, source
 * - NOTE: uses SERVICE_ROLE_KEY from .env.local so keep this file local/dev only.
 */

const SUPABASE_URL = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
  console.error("Missing SUPABASE_URL or SERVICE_ROLE_KEY in env.");
}

export async function GET(req) {
  try {
    const url = new URL(req.url);
    const search = url.searchParams;

    // Build select clause (default *)
    const select = search.get("select") || "*";

    // source filter (e.g. in.(global,world) or eq.global)
    const source = search.get("source");

    // pagination/limit (optional)
    const limit = search.get("limit") ? parseInt(search.get("limit")) : null;

    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, { auth: { persistSession: false } });

    let query = supabase.from("events").select(select);

    if (source) {
      // support `in.(global,world)` or `eq.global`
      if (source.startsWith("in.(") && source.endsWith(")")) {
        const inside = source.slice(4, -1).split(",").map(s => s.trim());
        query = query.in("source", inside);
      } else if (source.startsWith("eq.")) {
        const val = source.slice(3);
        query = query.eq("source", val);
      } else {
        // fallback: attempt eq
        query = query.eq("source", source);
      }
    }

    if (limit) {
      query = query.limit(limit);
    }

    const { data, error } = await query.order("created_at", { ascending: false });

    if (error) {
      console.error("Supabase query error:", error);
      return NextResponse.json({ ok: false, error: error.message }, { status: 500 });
    }

    return NextResponse.json({ ok: true, data }, { status: 200 });
  } catch (err) {
    console.error("Unhandled error in /api/events:", err);
    return NextResponse.json({ ok: false, error: String(err) }, { status: 500 });
  }
}
