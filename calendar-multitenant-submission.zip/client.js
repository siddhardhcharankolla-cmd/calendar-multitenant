﻿import { createClient } from "@supabase/supabase-js";

/**
 * Client-side (browser) singleton Supabase client helper.
 * Uses NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.
 */
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.warn("NEXT_PUBLIC_SUPABASE env vars missing. Check .env.local", {
    NEXT_PUBLIC_SUPABASE_URL: !!SUPABASE_URL,
    NEXT_PUBLIC_SUPABASE_ANON_KEY: !!SUPABASE_ANON_KEY,
  });
}

export const supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { persistSession: true },
});
