﻿// app/org/[slug]/admin/page.jsx
import React from "react";
import { createClient } from "../../../../src/utils/supabase/client.server.js";
// server page: app/org/[slug]/admin/page.jsx
import ImportButton from "../../../components/ImportButton.client.jsx";



// app/org/[slug]/admin/page.jsx

/**
 * Server component: Org Admin
 * - shows global events (with Import button next to each)
 * - shows organization-specific events below
 */
export default async function AdminPage({ params }) {
  // Next.js app router: params may be a promise — await it
  const { slug } = await params;
  if (!slug) {
    return <div style={{ padding: 24 }}>Missing organization slug in path.</div>;
  }

  // create server supabase client (reads env)
  const supabase = createClient();

  // lookup organization row by slug
  let orgRow = null;
  try {
    const { data: orgData, error: orgErr } = await supabase
      .from("organizations")
      .select("id,slug,name")
      .eq("slug", slug)
      .maybeSingle();

    if (orgErr) {
      console.error("[AdminPage] org lookup error:", orgErr);
    }
    orgRow = orgData ?? null;
  } catch (err) {
    console.error("[AdminPage] org lookup unexpected error:", err);
  }

  if (!orgRow) {
    return (
      <main style={{ padding: 24 }}>
        <h1>Org Admin</h1>
        <p>Organization "{slug}" not found.</p>
      </main>
    );
  }

  // fetch global events (source global/world)
  let globalEvents = [];
  try {
    const { data, error } = await supabase
      .from("events")
      .select("*")
      .in("source", ["global", "world"])
      .order("event_date", { ascending: true })
      .limit(200);

    if (error) {
      console.error("[AdminPage] error loading global events:", error);
    } else {
      globalEvents = data ?? [];
    }
  } catch (err) {
    console.error("[AdminPage] unexpected error loading global events:", err);
  }

  // fetch organization events
  let orgEvents = [];
  try {
    const { data, error } = await supabase
      .from("events")
      .select("*")
      .eq("organization_id", orgRow.id)
      .order("event_date", { ascending: true })
      .limit(500);

    if (error) {
      console.error("[AdminPage] error loading org events:", error);
    } else {
      orgEvents = data ?? [];
    }
  } catch (err) {
    console.error("[AdminPage] unexpected error loading org events:", err);
  }

  // Render UI
  return (
    <main style={{ padding: 24 }}>
      <h1 style={{ marginBottom: 6 }}>Org Admin — {orgRow.name ?? slug}</h1>
      <p style={{ marginTop: 0, color: "#666" }}>Manage events for this organization. Import global events into this org using the button.</p>

      <section style={{ marginTop: 28 }}>
        <h2 style={{ marginBottom: 8 }}>Global events</h2>
        {globalEvents.length === 0 ? (
          <div style={{ color: "#666" }}>No global events found.</div>
        ) : (
          <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
            {globalEvents.map((ev) => (
              <li
                key={ev.id}
                style={{
                  display: "flex",
                  alignItems: "flex-start",
                  justifyContent: "space-between",
                  padding: "12px 0",
                  borderBottom: "1px solid #eee"
                }}
              >
                <div style={{ maxWidth: "75%" }}>
                  <h3 style={{ margin: 0 }}>
                    {ev.name} <span style={{ fontWeight: "normal", fontSize: 13, color: "#666" }}>— {ev.event_date ?? "date TBD"}</span>
                  </h3>
                  {ev.title && <div style={{ marginTop: 6, color: "#333" }}>{ev.title}</div>}
                  {ev.description && <div style={{ marginTop: 6, color: "#444" }}>{ev.description}</div>}
                  <div style={{ marginTop: 8, fontSize: 12, color: "#666" }}>{ev.country ?? "Global"}</div>
                </div>

                <div style={{ marginLeft: 16, display: "flex", alignItems: "center" }}>
                  {/* client component import button - server component passes slug and event */}
                  <ImportButton slug={slug} event={ev} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section style={{ marginTop: 36 }}>
        <h2 style={{ marginBottom: 8 }}>Organization events</h2>

        {orgEvents.length === 0 ? (
          <div style={{ color: "#666" }}>No events for this organization yet.</div>
        ) : (
          <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
            {orgEvents.map((ev) => (
              <li key={ev.id} style={{ padding: "12px 0", borderBottom: "1px solid #f2f2f2" }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
                  <div>
                    <strong>{ev.name}</strong>{" "}
                    <span style={{ color: "#666", fontSize: 13 }}>— {ev.event_date ?? "date TBD"}</span>
                    {ev.title && <div style={{ color: "#333", marginTop: 6 }}>{ev.title}</div>}
                    {ev.description && <div style={{ color: "#444", marginTop: 6 }}>{ev.description}</div>}
                  </div>
                  <div style={{ minWidth: 120, textAlign: "right", color: "#666", fontSize: 12 }}>
                    <div>ID: {ev.id}</div>
                    <div style={{ marginTop: 6 }}>{ev.source}</div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}
