﻿import React from "react";
import { createClient } from "../../../src/utils/supabase/client.server.js";
import OrgFilter from "../../components/OrgFilter.client.jsx";
import ImportButton from "../../../components/ImportButton.client.jsx";
import OrgPageClient from "../../components/OrgPageClient.client.jsx";

export default async function OrgPage({ params, searchParams }) {
  const { slug } = await params;
  const sp = await searchParams;

  const supabase = createClient();

  // Look up organization
  const { data: orgRow } = await supabase
    .from("organizations")
    .select("id, slug, name")
    .eq("slug", slug)
    .maybeSingle();

  if (!orgRow) return <div>Organization not found</div>;

  // Fetch org events
  const { data: orgEvents } = await supabase
    .from("events")
    .select("*")
    .eq("organization_id", orgRow.id)
    .order("event_date", { ascending: true });

  return (
    <OrgPageClient>
      <div style={{ padding: 24 }}>
        <h1>Events for {orgRow?.name ?? slug}</h1>

        <OrgFilter />

        <ul style={{ listStyle: "none", padding: 0 }}>
          {orgEvents?.map((ev) => (
            <li
              key={ev.id}
              style={{
                padding: "10px 0",
                borderBottom: "1px solid #ddd",
              }}
            >
              <strong>{ev.title || ev.name}</strong> — {ev.event_date}
              <div style={{ fontSize: 12, color: "#666" }}>
                {ev.description}
              </div>
            </li>
          ))}
        </ul>
      </div>
    </OrgPageClient>
  );
}
